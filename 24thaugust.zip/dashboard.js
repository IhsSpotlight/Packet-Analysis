// SENTINEL SOC dashboard JS
// Unlike the sensor's own dashboard (live SocketIO feed from a running
// capture), this reads from the central DB via polling — the SOC server
// has no live packet stream of its own, just what sensors have forwarded.

const POLL_INTERVAL_MS = 5000;
let currentRole = null;
let currentNetworkFilter = "";  // "" = no filter (soc_admin "all networks")

function fmtTime(ts) {
  return new Date(ts * 1000).toTimeString().split(" ")[0];
}

function severityClass(sev) {
  return "sev-" + sev;
}

// ---------------- login ----------------

async function tryRestoreSession() {
  const resp = await fetch("/api/me");
  if (resp.ok) {
    const me = await resp.json();
    enterApp(me);
    return true;
  }
  return false;
}

function showLoginError(msg) {
  const el = document.getElementById("login-error");
  el.textContent = msg;
  el.classList.remove("hidden");
}

async function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;

  const resp = await fetch("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });

  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    showLoginError(err.error || "login failed");
    return;
  }
  const me = await resp.json();
  enterApp(me);
}

async function handleLogout() {
  await fetch("/api/logout", { method: "POST" });
  location.reload();
}

function enterApp(me) {
  currentRole = me.role;
  document.getElementById("login-screen").classList.add("hidden");
  document.getElementById("app").classList.remove("hidden");
  document.getElementById("user-label").textContent = me.username;
  document.getElementById("role-label").textContent = me.role;

  const switcherWrap = document.getElementById("network-switcher-wrap");
  if (me.role === "soc_admin") {
    switcherWrap.classList.remove("hidden");
    loadNetworkOptions();
  } else {
    switcherWrap.classList.add("hidden");
  }

  refreshData();
  setInterval(refreshData, POLL_INTERVAL_MS);
  startClock();
}

// ---------------- data loading ----------------

async function loadNetworkOptions() {
  const resp = await fetch("/api/networks");
  if (!resp.ok) return;
  const networks = await resp.json();

  const select = document.getElementById("network-switcher");
  // keep the "ALL NETWORKS" option, append the rest
  select.innerHTML = '<option value="">ALL NETWORKS</option>' +
    networks.map((n) => `<option value="${n.name}">${n.name.toUpperCase()}</option>`).join("");

  select.addEventListener("change", () => {
    currentNetworkFilter = select.value;
    refreshData();
  });

  renderNetworksList(networks);
}

function renderNetworksList(networks) {
  const el = document.getElementById("networks-list");
  if (!networks.length) {
    el.innerHTML = '<div class="type-empty">&mdash;</div>';
    return;
  }
  el.innerHTML = networks.map((n) => `
    <div class="type-row">
      <span class="name">${n.name}</span>
    </div>`).join("");
}

function queryString() {
  return currentNetworkFilter ? `?network=${encodeURIComponent(currentNetworkFilter)}` : "";
}

async function refreshData() {
  const [alertsResp, statsResp] = await Promise.all([
    fetch(`/api/alerts${queryString()}`),
    fetch(`/api/stats${queryString()}`),
  ]);

  if (alertsResp.status === 401 || statsResp.status === 401) {
    location.reload();  // session expired — back to login
    return;
  }

  const alerts = await alertsResp.json();
  const stats = await statsResp.json();

  renderFeed(alerts);
  renderStats(stats);
}

function renderFeed(alerts) {
  const feed = document.getElementById("feed");
  document.getElementById("feed-count").textContent = `${alerts.length} event${alerts.length === 1 ? "" : "s"}`;

  if (alerts.length === 0) {
    feed.innerHTML = '<div class="feed-empty" id="feed-empty">&gt; no alerts for this scope yet.</div>';
    return;
  }

  feed.innerHTML = alerts.map((a) => `
    <div class="alert-row ${severityClass(a.severity)}">
      <span class="alert-time">${fmtTime(a.event_timestamp)}</span>
      <span class="alert-sev">${a.severity.toUpperCase()}</span>
      <span class="alert-msg">
        <span class="alert-type-tag">${a.alert_type}</span>
        <span class="alert-src">${a.src_ip}</span><br>
        ${a.message}
      </span>
    </div>
  `).join("");
}

function renderStats(stats) {
  const sevs = ["critical", "high", "medium", "low"];
  const bySev = stats.by_severity || {};
  const maxSev = Math.max(1, ...sevs.map((s) => bySev[s] || 0));

  sevs.forEach((s) => {
    const row = document.querySelector(`.bar-row[data-sev="${s}"]`);
    if (!row) return;
    const count = bySev[s] || 0;
    row.querySelector(".bar-fill").style.width = `${(count / maxSev) * 100}%`;
    row.querySelector(".bar-value").textContent = count;
  });

  const typeList = document.getElementById("type-list");
  const entries = Object.entries(stats.by_type || {}).sort((a, b) => b[1] - a[1]);
  typeList.innerHTML = entries.length === 0
    ? '<div class="type-empty">&mdash;</div>'
    : entries.map(([name, count]) => `
        <div class="type-row"><span class="name">${name}</span><span class="count">${count}</span></div>`
      ).join("");
}

function startClock() {
  const clockEl = document.getElementById("clock");
  setInterval(() => {
    clockEl.textContent = new Date().toTimeString().split(" ")[0];
  }, 1000);
}

document.addEventListener("DOMContentLoaded", async () => {
  document.getElementById("login-form").addEventListener("submit", handleLogin);
  document.getElementById("logout-btn").addEventListener("click", handleLogout);

  const restored = await tryRestoreSession();
  if (!restored) {
    document.getElementById("login-screen").classList.remove("hidden");
  }
});
